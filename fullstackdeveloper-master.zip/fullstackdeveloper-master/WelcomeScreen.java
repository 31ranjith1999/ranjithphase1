package fullStackDeveloper;

public class WelcomeScreen {
	
	public void welcomescreen() {
		
	System.out.println("-------------------------------------------");	
	System.out.println("-----------Application Details-------------");
	System.out.println("--------------LockedMe.com-----------------");
	System.out.println("------Developed by Sandeep Kumar Pamu------");
	System.out.println("-------------------------------------------");
	System.out.println("Feature are listed below");
	
}
}